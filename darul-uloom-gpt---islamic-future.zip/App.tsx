import React, { useState } from 'react';
import { Message } from './types';
import { getGeminiResponse } from './services/geminiService';
import Header from './components/Header';
import ChatHistory from './components/ChatHistory';
import ChatInput from './components/ChatInput';

const App: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    const handleSendMessage = async (text: string) => {
        if (!text.trim() || isLoading) return;
        
        const userMessage: Message = {
            id: `user-${Date.now()}`,
            text,
            sender: 'user',
            createdAt: Date.now(),
        };

        // Add user message and a temporary loading message for the model
        setMessages(prevMessages => [
            ...prevMessages, 
            userMessage,
            { 
                id: `loading-${Date.now()}`, 
                sender: 'model', 
                text: '', 
                isLoading: true, 
                createdAt: Date.now(),
                displayName: 'Darul Uloom GPT',
            }
        ]);
        
        setIsLoading(true);

        try {
            const modelText = await getGeminiResponse(text);
            
            const modelMessage: Message = {
                id: `model-${Date.now()}`,
                text: modelText,
                createdAt: Date.now(),
                displayName: 'Darul Uloom GPT',
                sender: 'model',
                isError: modelText.startsWith('Sorry'),
                isVerified: !modelText.startsWith('Sorry')
            };

            // Replace loading message with the actual model response
            setMessages(prevMessages => [
                ...prevMessages.slice(0, -1),
                modelMessage
            ]);

        } catch (error) {
            console.error("Error sending message to Gemini:", error);
            const errorMessage: Message = {
                id: `error-${Date.now()}`,
                text: "Sorry, I couldn't get a response. Please try again.",
                createdAt: Date.now(),
                displayName: 'Darul Uloom GPT',
                sender: 'model',
                isError: true
            };
             // Replace loading message with the error message
             setMessages(prevMessages => [
                ...prevMessages.slice(0, -1),
                errorMessage
            ]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-screen bg-gray-100 dark:bg-gray-900 transition-colors duration-300">
            <Header />
            <ChatHistory messages={messages} />
            <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
        </div>
    );
};

export default App;