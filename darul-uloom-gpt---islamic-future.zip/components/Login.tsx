import React from 'react';

const Login: React.FC = () => null;

export default Login;