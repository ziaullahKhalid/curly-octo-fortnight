import React from 'react';

const DropdownMenu: React.FC = () => null;

export default DropdownMenu;
