import React from 'react';

const SavedChatsModal: React.FC = () => null;

export default SavedChatsModal;
