import React, { useRef, useEffect } from 'react';
import { Message } from '../types';
import ChatMessage from './ChatMessage';

interface ChatHistoryProps {
  messages: Message[];
}

const ChatHistory: React.FC<ChatHistoryProps> = ({ messages }) => {
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div id="chat-container" className="flex-grow overflow-y-auto p-4 md:p-6 bg-white dark:bg-gray-800 transition-colors duration-300">
      {messages.length > 0 ? (
        <div className="flex flex-col space-y-4">
          {messages.map((msg) => (
            <ChatMessage 
                key={msg.id} 
                message={msg}
            />
          ))}
          <div ref={endOfMessagesRef} />
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 dark:text-gray-400">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200">Darul Uloom GPT</h2>
            <p className="mt-2">Your conversation will appear here. Send a message to get started.</p>
        </div>
      )}
    </div>
  );
};

export default ChatHistory;