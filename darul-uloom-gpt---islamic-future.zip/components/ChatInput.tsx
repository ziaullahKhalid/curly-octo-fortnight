import React, { useState } from 'react';
import { SendIcon } from './icons/SendIcon';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [text, setText] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading || !text.trim()) return;
    onSendMessage(text);
    setText('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit(e as unknown as React.FormEvent);
    }
  }

  return (
    <div className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-2 sm:p-4 sticky bottom-0 transition-colors duration-300 shrink-0">
      <div className="flex items-center max-w-3xl mx-auto">
        <form onSubmit={handleSubmit} className="flex items-center w-full">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message..."
              disabled={isLoading}
              rows={1}
              className="flex-grow resize-none p-3 text-base bg-white dark:bg-gray-700 dark:text-gray-200 border border-gray-400 dark:border-gray-600 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 transition duration-200 disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={isLoading || !text.trim()}
              className="ml-2 sm:ml-4 flex-shrink-0 bg-blue-600 text-white rounded-full p-3 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
              aria-label="Send message"
            >
              <SendIcon />
            </button>
        </form>
      </div>
       {isLoading && <p className="text-center text-xs text-gray-500 dark:text-gray-400 pt-1">Gemini is thinking...</p>}
    </div>
  );
};

export default ChatInput;
