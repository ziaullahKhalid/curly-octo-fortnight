import React from 'react';

const Toast: React.FC = () => null;

export default Toast;
