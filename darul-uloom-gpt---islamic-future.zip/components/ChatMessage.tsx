import React from 'react';
import { Message } from '../types';
import TypingIndicator from './TypingIndicator';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

declare global {
    interface Window {
        marked: {
            parse: (markdown: string) => string;
        };
    }
}

const ChatMessage: React.FC<{ message: Message }> = ({ message }) => {
    const isUserMessage = message.sender === 'user';
    
    const createMarkup = (text: string) => {
        if (!text) return { __html: '' };
        return { __html: window.marked.parse(text) };
    };

    const containerClasses = `flex items-end gap-2 max-w-full ${isUserMessage ? 'justify-end' : 'justify-start'}`;
    const bubbleClasses = `max-w-xl lg:max-w-2xl px-4 py-2 rounded-2xl shadow-sm break-words`;
    const userBubbleClasses = `bg-blue-600 text-white`;
    const modelBubbleClasses = `bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200`;
    const errorBubbleClasses = `bg-red-100 text-red-700 border border-red-200`;
    
    const GeminiAvatar = () => (
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-indigo-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
            G
        </div>
    );

    const VerifiedBadge = () => (
        <div className="flex items-center text-xs text-green-600 dark:text-green-400 mt-2">
            <CheckCircleIcon />
            <span className="ml-1 font-semibold">Verified by Scholar</span>
        </div>
    );

    return (
        <div className={containerClasses}>
            {!isUserMessage && (
                message.photoURL ? 
                <img src={message.photoURL} alt={message.displayName || 'Avatar'} className="w-8 h-8 rounded-full flex-shrink-0" referrerPolicy="no-referrer" /> :
                <GeminiAvatar />
            )}
            <div className="flex flex-col">
                <div className={`${bubbleClasses} ${isUserMessage ? userBubbleClasses : modelBubbleClasses} ${message.isError ? errorBubbleClasses : ''}`}>
                    {!isUserMessage && <p className="text-xs font-bold mb-1 opacity-70">{message.displayName || 'User'}</p>}
                    {message.isLoading ? <TypingIndicator /> : <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1" dangerouslySetInnerHTML={createMarkup(message.text)} />}
                </div>
                {!isUserMessage && message.isVerified && <VerifiedBadge />}
            </div>
        </div>
    );
};

export default ChatMessage;