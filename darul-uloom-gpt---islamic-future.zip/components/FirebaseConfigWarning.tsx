import React from 'react';

const FirebaseConfigWarning: React.FC = () => {
    return null;
};

export default FirebaseConfigWarning;