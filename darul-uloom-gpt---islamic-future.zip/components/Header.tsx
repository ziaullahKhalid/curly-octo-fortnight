import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100 p-4 flex items-center justify-between shadow-md z-20 shrink-0">
            <div>
                <h1 className="text-xl md:text-2xl font-bold">Darul Uloom GPT</h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">Islamic Future</p>
            </div>
        </header>
    );
};

export default Header;