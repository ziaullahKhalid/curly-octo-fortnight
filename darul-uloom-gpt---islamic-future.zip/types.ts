export type Sender = 'user' | 'model';

export interface Message {
  id: string;
  text: string;
  sender: Sender;
  createdAt: number; // Using JS timestamp
  displayName?: string | null;
  photoURL?: string | null;
  isLoading?: boolean;
  isError?: boolean;
  isVerified?: boolean;
}