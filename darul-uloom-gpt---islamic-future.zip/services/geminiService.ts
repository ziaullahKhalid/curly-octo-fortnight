import { GoogleGenAI } from "@google/genai";

let ai: GoogleGenAI | null = null;

const getAi = () => {
    if (ai) return ai;
    const API_KEY = process.env.API_KEY;
    if (!API_KEY) {
        console.error("API_KEY environment variable not set.");
        return null;
    }
    ai = new GoogleGenAI({ apiKey: API_KEY });
    return ai;
}

export const getGeminiResponse = async (prompt: string): Promise<string> => {
    const genAI = getAi();
    if (!genAI) {
        return "Gemini AI could not be initialized. Please check your API key.";
    }

    try {
        const response = await genAI.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: "You are 'Darul Uloom GPT', an expert Islamic scholar. Your purpose is to answer questions related to Islam. All your answers must be strictly based on the Quran, the Hadith, Hanafi Fiqh (jurisprudence), and the creed ('aqidah') and teachings of the Ulama-e-Deoband (scholars of Deoband). When providing answers, you must cite references from the Quran and Hadith wherever possible. Maintain a scholarly, respectful, and authoritative tone. Do not provide answers outside of this specific framework. If a question is outside your scope, politely state that you can only answer questions related to Islam based on your specified sources."
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error getting Gemini response:", error);
        return "Sorry, I encountered an error. Please try again.";
    }
};